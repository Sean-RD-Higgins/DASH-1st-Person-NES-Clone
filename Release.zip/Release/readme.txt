copyright, rights, legal crock:
If you haven't figured it out, I don't own anything at all from the Zelda series (GASP!)
Those textures?  Ain't mine either.  Ripped from Zelda 1.
That sword? from freeobj.com by a guy name Dave.  Cool guy, makes a really good Mabo Curry, and free .obj swords too apparently.
About that Redead... its from OoT, but I got this one from Mrglitch2000 at http://facepunch.com/showthread.php?t=1110729
Every ounce of code is mine.... ok, main() was mostly supplied to us from Frisbee.
http://noproblo.dayjo.org/ZeldaSounds/ has those awesome 
References from stackoverflow are just about everywhere where I needed duct-tape, but I still made 99.9999% of the code.
http://en.wikipedia.org/wiki/File:Mammatus-storm-clouds_San-Antonio.jpg for clouds
